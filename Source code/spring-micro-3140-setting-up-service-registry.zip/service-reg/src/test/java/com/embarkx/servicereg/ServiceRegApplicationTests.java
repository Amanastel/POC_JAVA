package com.embarkx.servicereg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
