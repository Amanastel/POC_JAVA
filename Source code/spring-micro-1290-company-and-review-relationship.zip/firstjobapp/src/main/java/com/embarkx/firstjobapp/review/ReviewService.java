package com.embarkx.firstjobapp.review;

public interface ReviewService {
}
