package com.embarkx.firstjobapp.review.impl;

import com.embarkx.firstjobapp.review.ReviewService;
import org.springframework.stereotype.Service;

@Service
public class ReviewServiceImpl implements ReviewService {
}
