package com.embarkx.firstjobapp.company.impl;

public class CompanyServiceImpl {
}
