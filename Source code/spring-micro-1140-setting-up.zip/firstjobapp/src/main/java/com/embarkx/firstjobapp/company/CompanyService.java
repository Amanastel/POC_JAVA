package com.embarkx.firstjobapp.company;

public class CompanyService {
}
