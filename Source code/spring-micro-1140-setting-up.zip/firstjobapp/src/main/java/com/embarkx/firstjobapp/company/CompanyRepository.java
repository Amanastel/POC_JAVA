package com.embarkx.firstjobapp.company;

public interface CompanyRepository {
}
